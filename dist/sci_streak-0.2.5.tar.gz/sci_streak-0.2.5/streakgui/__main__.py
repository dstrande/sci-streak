if __name__ == "__main__":
    from streakgui.gui import gui
    gui.application()
